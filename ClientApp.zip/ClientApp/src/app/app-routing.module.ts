import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthLayoutComponent } from './auth/auth-layout/auth-layout.component';
import { ChangePasswordComponent } from './auth/change-password/change-password.component';
import { ForgotPasswordComponent } from './auth/forgot-password/forgot-password.component';
import { LoginComponent } from './auth/login/login.component';
import { LogoutComponent } from './auth/logout/logout.component';
import { ResetPasswordComponent } from './auth/reset-password/reset-password.component';

import { AccessdeniedComponent } from './home/accessdenied/accessdenied.component';
import { DashboardComponent } from './home/dashboard/dashboard.component';
import { HomeLayoutComponent } from './home/home-layout/home-layout.component';
import { DatabasemasterComponent } from './pages/databasemaster/databasemaster.component';
import { ManageComponent } from './pages/databasemaster/manage/manage.component';
import { ErrorpageComponent } from './pages/errorpage/errorpage.component';
import { MenusComponent } from './pages/menus/menus.component';
import { MenustreeComponent } from './pages/menustree/menustree.component';
import { PageNotfoundComponent } from './pages/page-notfound/page-notfound.component';
import { PermissionsComponent } from './pages/permissions/permissions.component';
import { RolemenuComponent } from './pages/rolemenu/rolemenu.component';
import { RolepermissionsComponent } from './pages/rolepermissions/rolepermissions.component';
import { RolesComponent } from './pages/roles/roles.component';
import { UserEditComponent } from './pages/user-edit/user-edit.component';
import { UserpermissionsComponent } from './pages/userpermissions/userpermissions.component';
import { UserrolesComponent } from './pages/userroles/userroles.component';
import { UsersComponent } from './pages/users/users.component';
import { UsersitesComponent } from './pages/usersites/usersites.component';
import { AuthGuardGuard } from './_helpers/auth-guard.guard';

const routes: Routes = [
  {
    path: 'Admin',
    loadChildren: () => import('./pages/pages.module').then(mod => mod.PagesModule)
  },
  {
    path: 'auth',
    component: AuthLayoutComponent,
    children: [
      { path: 'login', component: LoginComponent, pathMatch: 'full' },
      { path: 'forgotpassword', component: ForgotPasswordComponent, pathMatch: 'full' },
      { path: 'reset-password', component: ResetPasswordComponent, pathMatch: 'full' },
      { path: 'logout', component: LogoutComponent, pathMatch: 'full' },

    ]
  }
  //,{
  //  path: '',
  //  component: HomeLayoutComponent,
  //  children: [
  //    { path: 'dashboard', component: DashboardComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
  //    { path: 'menus', component: MenusComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
  //    { path: 'roles', component: RolesComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
  //    { path: 'users', component: UsersComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
  //    { path: 'accessdenied', component: AccessdeniedComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
  //    { path: 'databasemaster', component: DatabasemasterComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
  //    { path: 'menustree', component: MenustreeComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
  //    { path: 'userpermissions', component: UserpermissionsComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
  //    { path: 'rolepermissions', component: RolepermissionsComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
  //    { path: 'userroles', component: UserrolesComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
  //    { path: 'usersites', component: UsersitesComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
  //    { path: 'userpermissions', component: UserpermissionsComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
  //    { path: 'apilist', component: PermissionsComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
  //    { path: 'rolemenu', component: RolemenuComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
  //    { path: 'managedatabase', component: ManageComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
  //    { path: 'changepassword', component: ChangePasswordComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
  //    { path: 'user-profile', component: UserEditComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
  //    { path: 'errorpages', component: ErrorpageComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
  //    { path: '**', component: PageNotfoundComponent, canActivate: [AuthGuardGuard] },
  //  ], canActivate: [AuthGuardGuard]
  //},
 

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
