import { TestBed } from '@angular/core/testing';

import { DatabasemasterService } from './databasemaster.service';

describe('DatabasemasterService', () => {
  let service: DatabasemasterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DatabasemasterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
