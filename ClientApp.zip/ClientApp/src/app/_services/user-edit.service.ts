import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { UserEdit } from '../_models/userEdit';
import { BaseService } from './base.service';

@Injectable({
  providedIn: 'root'
})
export class UserEditService extends BaseService<UserEdit> {

  constructor(httpClient: HttpClient) {
    super(
      httpClient);
  }
}
