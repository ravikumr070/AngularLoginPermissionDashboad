import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Users } from '../_models/users';
import { BaseService } from './base.service';

@Injectable({
  providedIn: 'root'
})
export class UserService extends BaseService<Users>{

  constructor(httpClient: HttpClient) {
    super(
      httpClient);
  }
}
