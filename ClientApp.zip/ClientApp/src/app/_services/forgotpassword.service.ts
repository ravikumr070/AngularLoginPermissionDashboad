import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Forgotpassword } from '../_models/forgotpassword';
import { BaseService } from './base.service';

@Injectable({
  providedIn: 'root'
})
export class ForgotpasswordService extends BaseService<Forgotpassword> {

  constructor(httpClient: HttpClient) {
    super(
      httpClient);
  }
}
