import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { TokenStorageService } from './token-storage.service';
import { Router } from '@angular/router';
import { map } from 'rxjs/operators';
import { Token } from "../_models/token";
import { UserEdit } from '../_models/userEdit';
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
const AUTH_API = 'https://localhost:44339/';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private userSubject: BehaviorSubject<UserEdit>;
  public user: Observable<UserEdit>;
  userD1: any;
  constructor(private http: HttpClient, private token: TokenStorageService, private router: Router) {

    this.userSubject = new BehaviorSubject<UserEdit>(this.userD1);
    this.user = this.userSubject.asObservable();
 
  }
  public get userValue(): any {
    debugger;
    //return this.userSubject.value;
    return this.token.getToken();
  }
  login(username: string, password: string): Observable<any> {
    return this.http.post(AUTH_API + 'Auth/Login', {
      username,
      password
    }, httpOptions);
  }
  UserLogin(username: string, password: string): any {
    this.login(username, password).subscribe(
      data => {
        debugger;
        this.token.saveToken(data.accessToken);
        
        this.token.saveRefreshToken(data.refreshToken);
        this.getCurrentUserData();
        return true;
        
      },
      err => {
        return false;
      }
    );
  }
  getCurrentUserData() {
    this.getCurrentUser().subscribe(
      data => {
        debugger;
        this.token.saveUser(data);
        
        this.userSubject.next(data);
        this.router.navigate(['/dashboard']);
      },
      err => {
       
        console.log(err.error.message);
      }
    );
  }
  getCurrentUser(): Observable<any> {
    return this.http.get(AUTH_API + 'Users/GetCurrentUser'
    , httpOptions);
  }
  logout() {
    
    this.stopRefreshTokenTimer();
    this.token.removeToken();
    this.userSubject.next(this.userD1);
    this.router.navigate(['/auth/login']);
  }
  register(username: string, email: string, password: string): Observable<any> {
    return this.http.post(AUTH_API + 'signup', {
      username,
      email,
      password
    }, httpOptions);
  }
  refreshToken(token: string) {
    return this.http.get(AUTH_API + 'auth/refreshtoken/' + token
    , httpOptions);
  }
  private refreshTokenTimeout;

  private startRefreshTokenTimer() {
    
    const jwtToken = JSON.parse(atob(this.userValue.jwtToken.split('.')[1]));

    const expires = new Date(jwtToken.exp * 1000);
    const timeout = expires.getTime() - Date.now() - (60 * 1000);
    this.refreshTokenTimeout = setTimeout(() => this.refreshToken(jwtToken).subscribe(), timeout);
  }

  private stopRefreshTokenTimer() {
    clearTimeout(this.refreshTokenTimeout);
  }
  refreshTokenservice(token: string) {
    return this.http.get<any>(AUTH_API + 'auth/refreshtoken/' + token)
      .pipe(map((Token) => {
       
        this.startRefreshTokenTimer();
        return Token;
      }));
  }
}
