import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Databasemaster } from '../_models/databasemaster';
import { BaseService } from './base.service';

@Injectable({
  providedIn: 'root'
})
export class DatabasemasterService extends BaseService<Databasemaster> {

  constructor(httpClient: HttpClient) {
    super(
      httpClient);
  }
}
