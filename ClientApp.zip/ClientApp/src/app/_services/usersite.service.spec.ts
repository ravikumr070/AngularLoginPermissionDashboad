import { TestBed } from '@angular/core/testing';

import { UsersiteService } from './usersite.service';

describe('UsersiteService', () => {
  let service: UsersiteService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UsersiteService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
