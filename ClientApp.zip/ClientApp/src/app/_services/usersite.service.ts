import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { UserSite, UserSiteList } from '../_models/usersite';
import { BaseService } from './base.service';

@Injectable({
  providedIn: 'root'
})
export class UsersiteService extends BaseService<UserSite> {

  constructor(httpClient: HttpClient) {
    super(
      httpClient);
  }
}
