import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Rolemenu } from '../_models/rolemenu';

import { BaseService } from './base.service';

@Injectable({
  providedIn: 'root'
})
export class RoleMenuService extends BaseService<Rolemenu> {

  constructor(httpClient: HttpClient) {
    super(
      httpClient);
  }
}
