import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Permission } from '../_models/permission';
import { Rolepermission } from '../_models/rolepermission';
import { BaseService } from './base.service';

@Injectable({
  providedIn: 'root'
})
export class RolepermissionService extends BaseService<Rolepermission> {

  constructor(httpClient: HttpClient) {
    super(
      httpClient);
  }
}
