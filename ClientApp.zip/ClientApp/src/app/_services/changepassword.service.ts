import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Changepassword } from '../_models/changepassword';
import { BaseService } from './base.service';

@Injectable({
  providedIn: 'root'
})
export class ChangepasswordService extends BaseService<Changepassword> {

  constructor(httpClient: HttpClient) {
    super(
      httpClient);
  }
}
