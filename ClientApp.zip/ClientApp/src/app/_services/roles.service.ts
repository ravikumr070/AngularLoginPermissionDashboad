import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Roles } from '../_models/roles';
import { BaseService } from './base.service';

@Injectable({
  providedIn: 'root'
})
export class RolesService extends BaseService<Roles> {

  constructor(httpClient: HttpClient) {
    super(
      httpClient);
  }
}
