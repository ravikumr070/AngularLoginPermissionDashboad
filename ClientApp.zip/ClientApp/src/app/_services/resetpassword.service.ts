import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Resetpassword } from '../_models/resetpassword';
import { BaseService } from './base.service';

@Injectable({
  providedIn: 'root'
})
export class ResetpasswordService extends BaseService<Resetpassword> {

  constructor(httpClient: HttpClient) {
    super(
      httpClient);
  }
}
