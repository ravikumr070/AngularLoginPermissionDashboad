import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { Base } from '../_models/base';

@Injectable({
  providedIn: 'root'
})

export class BaseService<T extends Base> {
  
  constructor(
    private httpClient: HttpClient
   
  
  ) { }

  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  }

  //#region [ Public ]
  get(endpoint: string): Observable<T[]> {
    return this.httpClient
      .get<T[]>(`${environment.apiUrl}/${endpoint}`)
      .pipe(
        retry(2),
        catchError(this.handleError)
      )
  }

  getById(endpoint: string,id: any): Observable<T> {
    return this.httpClient
      .get<T>(`${environment.apiUrl}/${endpoint}/${id}`)
      .pipe(
        retry(2),
        catchError(this.handleError)
      )
  }

  create(endpoint: string,item: T): Observable<T> {
    return this.httpClient.post<T>(`${environment.apiUrl}/${endpoint}`, JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(2),
        catchError(this.handleError)
      )
  }
  post(endpoint: string, item: any): Observable<any> {
    return this.httpClient.post<any>(`${environment.apiUrl}/${endpoint}`, JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(2),
        catchError(this.handleError)
      )
  }
  getList(endpoint: string): Observable<any[]> {
    return this.httpClient
      .get<any[]>(`${environment.apiUrl}/${endpoint}`)
      .pipe(
        retry(2),
        catchError(this.handleError)
      )
  }
  update(endpoint: string,item: T): Observable<T> {
    return this.httpClient.put<T>(`${environment.apiUrl}/${endpoint}/${item.id}`, JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(2),
        catchError(this.handleError)
      )
  }

  delete(endpoint: string,item: T) {
    return this.httpClient.delete<T>(`${environment.apiUrl}/${endpoint}/${item.id}`, this.httpOptions)
      .pipe(
        retry(2),
        catchError(this.handleError)
      )
  }
  //#endregion

  //#region [ Private ]
  private handleError(error: HttpErrorResponse) {
    let errorMessage = '';

    if (error.error instanceof ErrorEvent) {
      //error client
      errorMessage = error.error.message;
    } else {
      //error server
      errorMessage = `Server status : ${error.status}, ` + `Error: ${error.message}`;
    }

    return throwError(errorMessage);
  }
  //#endregion

}
