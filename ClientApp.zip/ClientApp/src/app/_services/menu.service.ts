import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { Menu } from '../_models/menu';
import { BaseService } from './base.service';

@Injectable({
  providedIn: 'root'
})
export class MenuService extends BaseService<Menu> {
  
  constructor(httpClient: HttpClient) {
    super(
      httpClient);
  }
}
