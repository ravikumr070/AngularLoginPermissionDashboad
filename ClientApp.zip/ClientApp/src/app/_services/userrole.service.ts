import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Userrole } from '../_models/userroles';
import { BaseService } from './base.service';

@Injectable({
  providedIn: 'root'
})
export class UserroleService extends BaseService<Userrole> {

  constructor(httpClient: HttpClient) {
    super(
      httpClient);
  }
}
