import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userpermissions',
  templateUrl: './userpermissions.component.html',
  styleUrls: ['./userpermissions.component.sass']
})
export class UserpermissionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
