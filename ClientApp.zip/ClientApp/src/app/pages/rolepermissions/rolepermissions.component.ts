import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
import { Permission } from '../../_models/permission';
import { Rolepermission, RolepermissionDTO } from '../../_models/rolepermission';
import { NotificationService } from '../../_services/notification.service';
import { RolepermissionService } from '../../_services/rolepermission.service';

@Component({
  selector: 'app-rolepermissions',
  templateUrl: './rolepermissions.component.html',
  styleUrls: ['./rolepermissions.component.sass']
})
export class RolepermissionsComponent implements OnInit {

  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();
  permission = {} as Rolepermission;
  permissionlist: Rolepermission[] | undefined;
  constructor(private permissionService: RolepermissionService, private router: ActivatedRoute, private notifyService: NotificationService) { }

  ngOnInit(): void {
    this.loadData();
    this.loadDataTable();
  }
  getAll(id : string) {
    debugger;
    this.permissionService.get('UserPermissions/GetByRolePermission/' + id).subscribe((prm: Rolepermission[]) => {
      this.permissionlist = prm;
      this.dtTrigger.next();
    });
  }
  loadData() {
    this.router.queryParams.subscribe(params => {
      console.log(params.uid);
      this.getAll(params.uid);
    });
  }
  loadDataTable() {
    this.dtOptions = {
      pagingType: "simple_numbers",
      pageLength: 10,
      processing: true,

    };

  }

  changePermission(event, data) {
    debugger;
    this.permission = data;
    this.permission.hasPermission = event.target.checked;
    this.permission.createdBy = 'User';
    this.permission.ip = '1:1';
    this.permissionService.update('UserPermissions/Edit', this.permission).subscribe(() => {
      //this.loadData();
      if (event.target.checked) {

        this.notifyService.showSuccess("Permission saved successfully !!", "Permission")
      }
      else {
        this.notifyService.showError("Permission removed successfully !!", "Permission")
      }
    });
    
  }
  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

}
