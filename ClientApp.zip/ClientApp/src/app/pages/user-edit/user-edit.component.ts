import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserEdit } from '../../_models/userEdit';
import { AuthService } from '../../_services/auth.service';
import { NotificationService } from '../../_services/notification.service';
import { TokenStorageService } from '../../_services/token-storage.service';
import { UserEditService } from '../../_services/user-edit.service';

@Component({
  selector: 'app-user-edit',
  templateUrl: './user-edit.component.html',
  styleUrls: ['./user-edit.component.sass']
})
export class UserEditComponent implements OnInit {

  userForm = {} as FormGroup;
  userid: string = "";
  isFormSubmitted = false;
  user = {} as UserEdit;
  imageSrc: string = "";
  HimageSrc: string = "";
  constructor(private userprofileService: UserEditService, private tokentservice: TokenStorageService,
    private notifyService: NotificationService, private formBuilder: FormBuilder,
    private authService: AuthService, private http: HttpClient ) { }

  ngOnInit(): void {
    this.fomrmInit();
    this.getUser();

  }
  fomrmInit() {

    this.userForm = this.formBuilder.group({

      email: ['', [Validators.required, Validators.email]],
      phoneNumber: ['', [Validators.required]],
      name: ['', [Validators.required]],
      profileImage:[]
    }
    );


  }
  Save() {
    debugger;
    this.isFormSubmitted = true;
    if (this.userForm.invalid) {
      return;
    }
    this.user = this.tokentservice.getUser();
    this.user.name = this.userForm.value.name;
    this.user.email = this.userForm.value.email;
    this.user.phoneNumber = this.userForm.value.phoneNumber;
    this.user.profileImage = this.HimageSrc;
    
   

    this.userprofileService.create('Users/UpdateUser', this.user).subscribe(data => {
      debugger;
      this.getCurrentUser();
      this.notifyService.showSuccess("Data Updated successfully !!", "User")
      console.log(data);
      this.getUser();
    },
      err => {
       
        this.notifyService.showSuccess(err.error.message, "User")
      });
   
  }
  getUser() {
    debugger;
    var data = this.tokentservice.getUser();
    this.userid = data.id;
    this.userForm.patchValue(data);
    this.imageSrc = "https://localhost:44339/Resources/img/users/" + data.profileImage;
    this.HimageSrc = data.profileImage;
  }
  getCurrentUser() {
    this.authService.getCurrentUser().subscribe(
      data => {
        debugger;
        this.tokentservice.saveUser(data);
        console.log(data);
      },
      err => {
        console.log(err.error.message);
      
      }
    );
  }
  onFileChange(event) {
    const reader = new FileReader();

    if (event.target.files && event.target.files.length) {
      const [file] = event.target.files;
      reader.readAsDataURL(file);

      reader.onload = () => {

        this.imageSrc = reader.result as string;
        this.uploadFile(event.target.files);
        this.userForm.patchValue({
          fileSource: reader.result
        });

      };

    }
  }
  public uploadFile = (files) => {
    if (files.length === 0) {
      return;
    }
    debugger;
    let fileToUpload = <File>files[0];
    const formData = new FormData();
    formData.append('file', fileToUpload, fileToUpload.name);
    formData.append('FileOldName', this.HimageSrc);
    this.http.post('https://localhost:44339/Files/UploadFiles', formData)
      .subscribe(data => {
        debugger
        this.imageSrc = data[0];
        this.HimageSrc = data[0];;
        console.log(this.imageSrc);
      });
  }
}
