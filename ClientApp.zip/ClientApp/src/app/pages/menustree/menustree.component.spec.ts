import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MenustreeComponent } from './menustree.component';

describe('MenustreeComponent', () => {
  let component: MenustreeComponent;
  let fixture: ComponentFixture<MenustreeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MenustreeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MenustreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
