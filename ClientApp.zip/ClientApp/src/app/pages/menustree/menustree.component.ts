import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menustree',
  templateUrl: './menustree.component.html',
  styleUrls: ['./menustree.component.sass']
})
export class MenustreeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
