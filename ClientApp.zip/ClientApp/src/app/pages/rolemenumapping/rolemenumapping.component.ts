import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rolemenumapping',
  templateUrl: './rolemenumapping.component.html',
  styleUrls: ['./rolemenumapping.component.sass']
})
export class RolemenumappingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
