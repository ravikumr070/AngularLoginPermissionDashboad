import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsersitesComponent } from './usersites.component';

describe('UsersitesComponent', () => {
  let component: UsersitesComponent;
  let fixture: ComponentFixture<UsersitesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UsersitesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UsersitesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
