import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { UserSite, UserSiteList } from '../../_models/usersite';
import { NotificationService } from '../../_services/notification.service';
import { UsersiteService } from '../../_services/usersite.service';

@Component({
  selector: 'app-usersites',
  templateUrl: './usersites.component.html',
  styleUrls: ['./usersites.component.sass']
})
export class UsersitesComponent implements OnInit {

  userSite = {} as UserSite;
  AddUserSitesForm = {} as FormGroup;
  RemoveUserSitesForm = {} as FormGroup;
  userId: string = "";
  constructor(private usersiteService: UsersiteService, private notifyService: NotificationService, private router: ActivatedRoute, private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.fomrmInit();
    this.loadData();
  }
  getAll(id: string) {
    debugger;
    this.usersiteService.getById('UserMappings/GetAllByUserId', id).subscribe((site: UserSite) => {
      this.userSite = site;

    });
  }
  loadData() {
    this.router.queryParams.subscribe(params => {
      console.log(params.uid);
      this.userId = params.uid;
      this.getAll(params.uid);
    });
  }
  AddUserSites() {
    debugger;
    if (this.AddUserSitesForm.value.siteMasterId) {
      this.userSite.siteMasterId = this.AddUserSitesForm.value.siteMasterId;
      this.userSite.userId = this.userId;
      this.usersiteService.create('UserMappings/AssignToSites', this.userSite).subscribe(() => {
        this.notifyService.showSuccess("Data Saved successfully !!", "Sites")
        this.loadData();
      })
    }
  }
  RemoveUserSites() {
    debugger;
    if (this.RemoveUserSitesForm.value.siteMasterId) {
      this.userSite.siteMasterId = this.RemoveUserSitesForm.value.siteMasterId;
      this.userSite.userId = this.userId;
      this.usersiteService.create('UserMappings/RemoveFromSites', this.userSite).subscribe(() => {
        this.notifyService.showSuccess("Data Removed successfully !!", "Sites")
        this.loadData();
      })
    }
  }
  fomrmInit() {

    this.AddUserSitesForm = this.formBuilder.group({
      siteMasterId: [],


    });
    this.RemoveUserSitesForm = this.formBuilder.group({
      siteMasterId: [],


    });
  }
}
