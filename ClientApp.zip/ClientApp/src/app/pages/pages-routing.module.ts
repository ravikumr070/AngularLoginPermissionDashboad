import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeLayoutComponent } from '../home/home-layout/home-layout.component';
import { DashboardComponent } from '../home/dashboard/dashboard.component';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuardGuard } from '../_helpers/auth-guard.guard';
import { MenusComponent } from './menus/menus.component';
import { RolesComponent } from './roles/roles.component';
import { UsersComponent } from './users/users.component';
import { AccessdeniedComponent } from '../home/accessdenied/accessdenied.component';
import { DatabasemasterComponent } from './databasemaster/databasemaster.component';
import { MenustreeComponent } from './menustree/menustree.component';
import { UserpermissionsComponent } from './userpermissions/userpermissions.component';
import { RolepermissionsComponent } from './rolepermissions/rolepermissions.component';
import { UserrolesComponent } from './userroles/userroles.component';
import { UsersitesComponent } from './usersites/usersites.component';
import { PermissionsComponent } from './permissions/permissions.component';
import { RolemenuComponent } from './rolemenu/rolemenu.component';
import { ManageComponent } from './databasemaster/manage/manage.component';
import { ChangePasswordComponent } from '../auth/change-password/change-password.component';
import { UserEditComponent } from './user-edit/user-edit.component';
import { ErrorpageComponent } from './errorpage/errorpage.component';
import { PageNotfoundComponent } from './page-notfound/page-notfound.component';

const pageroutes: Routes = [

  
  {
    path: '',
    
    component: HomeLayoutComponent,
    children: [
      { path: 'dashboard', component: DashboardComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
      { path: 'menus', component: MenusComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
      { path: 'roles', component: RolesComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
      { path: 'users', component: UsersComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
      { path: 'accessdenied', component: AccessdeniedComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
      { path: 'databasemaster', component: DatabasemasterComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
      { path: 'menustree', component: MenustreeComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
      { path: 'userpermissions', component: UserpermissionsComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
      { path: 'rolepermissions', component: RolepermissionsComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
      { path: 'userroles', component: UserrolesComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
      { path: 'usersites', component: UsersitesComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
      { path: 'userpermissions', component: UserpermissionsComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
      { path: 'apilist', component: PermissionsComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
      { path: 'rolemenu', component: RolemenuComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
      { path: 'managedatabase', component: ManageComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
      { path: 'changepassword', component: ChangePasswordComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
      { path: 'user-profile', component: UserEditComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
      { path: 'errorpages', component: ErrorpageComponent, pathMatch: 'full', canActivate: [AuthGuardGuard] },
      { path: '**', component: PageNotfoundComponent, canActivate: [AuthGuardGuard] },
    ], canActivate: [AuthGuardGuard]
  },


];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(pageroutes)
  ],
  exports: [
    RouterModule
  ]
})
export class PagesRoutingModule { }
