import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { Roles } from '../../_models/roles';
import { Users } from '../../_models/users';
import { NotificationService } from '../../_services/notification.service';
import { UserService } from '../../_services/user.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.sass']
})
export class UsersComponent implements OnInit {
  
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();
  user = {} as Users;
  userlist: Users[] | undefined;
  rolelist: Roles[] | undefined;
  usersForm = {} as FormGroup;
  display = 'none';
  isFormSubmitted = false;
  IsEdit = true;
  resetUrl : string = "";
  constructor(private userService: UserService, private notifyService: NotificationService, private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit(): void {
    this.getAllRoles();
    this.getAll();
    this.loadDataTable();
    this.fomrmInit();

  }
  getAll() {
    debugger;
    this.userService.get('Users/UsersForList').subscribe((users: Users[]) => {
      this.userlist = users;
      this.dtTrigger.next();
    });
  }
  getAllRoles() {
    debugger;
    this.userService.get('Roles/Get').subscribe((roles: Roles[]) => {
      this.rolelist = roles;
    });
  }
  loadDataTable() {
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      processing: true
    };
    //setTimeout(() => {
    //  $('#tblUsers').DataTable({
    //    pagingType: 'full_numbers',
    //    pageLength: 10,
    //    processing: true,
    //    lengthMenu: [5, 10, 25, 50, 100, 200, 500]
    //  });
    //}, 1);
  }
  
  fomrmInit() {
    const PAT_NAME = "^[a-zA-Z ]{2,20}$";
    const PAT_PHONE = "^((\\+91-?)|0)?[0-9]{10}$";
    this.usersForm = this.formBuilder.group({
      id: [],
      name: ['', [Validators.required, Validators.pattern(PAT_NAME)]],
      email: ['', [Validators.required, Validators.email]],
      phoneNumber: ['', [Validators.required, Validators.pattern(PAT_PHONE)]],
      role: ['', [Validators.required]],
      approved: [],
      username: [],
      companyId: [],

    });
  }
  Save() {

    // Set flag to true
    this.isFormSubmitted = true;
    if (this.usersForm.invalid) {
      return;
    }
    // Form field values
    console.log(this.usersForm.value.name);
    this.saveData(this.usersForm.value);

  }
  closeModal() {

  }
  saveData(form: NgForm) {
    debugger;
    this.usersForm.value.username = this.usersForm.value.email;
    this.usersForm.value.approved = true;
    this.usersForm.value.companyId = 0;
    if (this.usersForm.value.id !== undefined && this.usersForm.value.id !== null) {
      this.userService.update('Users/UpdateUser', this.usersForm.value).subscribe(() => {
        this.notifyService.showSuccess("Data Updated successfully !!", "User")
        this.closeModalDialog();
        this.cleanForm(form);

      });
    } else {
      this.userService.create('Users/Create', this.usersForm.value).subscribe(() => {
        this.notifyService.showSuccess("Data Saved successfully !!", "User")
        this.closeModalDialog();
        this.cleanForm(form);
      });
    }

  }
  Edit(item) {
    debugger;
    this.IsEdit = false;
    this.usersForm.patchValue(item);
    this.openModalDialog();
  }
  cleanForm(form: NgForm) {
    this.getAll();
    this.usersForm.reset();
    this.user = {} as Users;

  }
  AddUser() {
    this.IsEdit = true;
    this.openModalDialog();
  }
  openModalDialog() {
    this.display = 'block'; 
  }

  closeModalDialog() {
    this.usersForm.reset();
    this.display = 'none'; 
  }
  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }
  navigateToUserRole(id: string) {
    this.router.navigate(["userroles"], { queryParams: { uid: id } });
  }
  SendCreds(item) {
    
    this.userService.post('Auth/GetPasswordResetTokenByEmail', item.email).subscribe(data => {
      console.log(data);
      this.resetUrl = 'http://localhost:4200/auth/reset-password?code=' + data.code + '&id=' + data.id;
      console.log(this.resetUrl);
      this.notifyService.showSuccess("Password Reset Link Sent successfully !!", "User")
      debugger;
    });
  
  }
}
