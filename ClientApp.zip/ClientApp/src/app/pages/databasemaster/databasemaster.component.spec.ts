import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DatabasemasterComponent } from './databasemaster.component';

describe('DatabasemasterComponent', () => {
  let component: DatabasemasterComponent;
  let fixture: ComponentFixture<DatabasemasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DatabasemasterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DatabasemasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
