import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { Databasemaster } from '../../_models/databasemaster';
import { DatabasemasterService } from '../../_services/databasemaster.service';
import { NotificationService } from '../../_services/notification.service';

@Component({
  selector: 'app-databasemaster',
  templateUrl: './databasemaster.component.html',
  styleUrls: ['./databasemaster.component.sass']
})
export class DatabasemasterComponent implements OnInit {
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();
  database = {} as Databasemaster;
  databaselist: Databasemaster[] | undefined;

  databaseForm = {} as FormGroup;
  display = 'none'; //default Variable
  isFormSubmitted = false;
  constructor(private databaseService: DatabasemasterService, private notifyService: NotificationService, private formBuilder: FormBuilder) { }

  ngOnInit(): void {

    this.getAll();
    this.loadDataTable();
    this.fomrmInit();

  }
  getAll() {
    debugger;
    this.databaseService.get('SiteMasters/Get').subscribe((db: Databasemaster[]) => {
      this.databaselist = db;
      this.dtTrigger.next();
    });
  }
  loadDataTable() {
    this.dtOptions = {
      pagingType: "simple_numbers",
      pageLength: 10,
      processing: true,

    };
   
  }
 
  fomrmInit() {
   
    this.databaseForm = this.formBuilder.group({
      id: [],
      siteId: ['', [Validators.required]],
      dbName: ['', [Validators.required]],
      prodDbConnectionString: ['',],
      uATDbConnectionString: ['', ],
      stagingDbConnectionString: ['',],
      dbUserId: ['', ],
      dbPassword: ['', ],
      dbHost: ['', ],

    });
  }
  Save() {

    // Set flag to true
    this.isFormSubmitted = true;
    if (this.databaseForm.invalid) {
      return;
    }
    // Form field values
    console.log(this.databaseForm.value.name);
    this.saveData(this.databaseForm.value);

  }
  closeModal() {

  }
  saveData(form: NgForm) {
    debugger;
    if (this.databaseForm.value.id !== undefined && this.databaseForm.value.id !== null) {
      this.databaseService.update('SiteMasters/Edit', this.databaseForm.value).subscribe(() => {
        this.notifyService.showSuccess("Data Updated successfully !!", "Database")
        this.closeModalDialog();
        this.cleanForm(form);

      });
    } else {
      this.databaseService.create('SiteMasters/Create', this.databaseForm.value).subscribe(() => {
        this.notifyService.showSuccess("Data Saved successfully !!", "Database")
        this.closeModalDialog();
        this.cleanForm(form);
      });
    }

  }
  Edit(item) {
    debugger;
    this.databaseForm.patchValue(item);
    this.openModalDialog();
  }
  cleanForm(form: NgForm) {
    this.getAll();
    this.databaseForm.reset();
    this.database = {} as Databasemaster;

  }
  openModalDialog() {
    this.display = 'block'; //Set block css
  }

  closeModalDialog() {
    this.databaseForm.reset();
    this.display = 'none'; //set none css after close dialog
  }
  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

}
