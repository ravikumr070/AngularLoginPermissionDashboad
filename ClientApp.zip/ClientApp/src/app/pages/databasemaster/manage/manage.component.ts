import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Databasemaster } from '../../../_models/databasemaster';
import { DatabasemasterService } from '../../../_services/databasemaster.service';
import { NotificationService } from '../../../_services/notification.service';

@Component({
  selector: 'app-manage',
  templateUrl: './manage.component.html',
  styleUrls: ['./manage.component.sass']
})
export class ManageComponent implements OnInit {

  database = {} as Databasemaster;
  databaselist: Databasemaster[] | undefined;

  databaseForm = {} as FormGroup;
  isFormSubmitted = false;
  constructor(private databaseService: DatabasemasterService,
    private notifyService: NotificationService, private routerLink: Router,
    private router: ActivatedRoute, private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.fomrmInit();
    this.router.queryParams.subscribe(params => {
      this.getData();
    });
  }
  getData() {
    this.router.queryParams.subscribe(params => {
      this.databaseService.getById('SiteMasters/Get', params.uid).subscribe((db: Databasemaster) => {
        this.database = db;
        this.databaseForm.patchValue(this.database);
      });
    });
   
  }
  fomrmInit() {

    this.databaseForm = this.formBuilder.group({
      id: [],
      siteId: ['', [Validators.required]],
      dbName: ['', [Validators.required]],
      prodDbConnectionString: ['',],
      uATDbConnectionString: ['',],
      stagingDbConnectionString: ['',],
      dbUserId: ['',],
      dbPassword: ['',],
      dbHost: ['',],

    });
  }
  Save() {

    // Set flag to true
    this.isFormSubmitted = true;
    if (this.databaseForm.invalid) {
      return;
    }
    // Form field values
    console.log(this.databaseForm.value.name);
    this.saveData(this.databaseForm.value);

  }
  
  saveData(form: NgForm) {
    debugger;
    this.database = this.databaseForm.value;
    this.database.createdBy = 'User';
    this.database.createdDate = '2021-09-10';
    this.database.ip = '1:1';
    this.database.isActive = true;
    this.database.isDeleted = false;
    if (this.databaseForm.value.id !== undefined && this.databaseForm.value.id !== null) {
      this.databaseService.update('SiteMasters/Edit', this.database).subscribe(() => {
        this.notifyService.showSuccess("Data Updated successfully !!", "Database")
       
        this.cleanForm(form);
        this.routerLink.navigate(['/databasemaster']);
      });
    } else {
      this.databaseService.create('SiteMasters/Create', this.database).subscribe(() => {
        this.notifyService.showSuccess("Data Saved successfully !!", "Database")
        
        this.cleanForm(form);
        this.routerLink.navigate(['/databasemaster']);
      });
    }

  }
  Edit(item) {
    debugger;
    this.databaseForm.patchValue(item);
  
  }
  cleanForm(form: NgForm) {
   
    this.databaseForm.reset();
    this.database = {} as Databasemaster;

  }
}
