import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NotificationService } from '../../_services/notification.service';
import { Rolemenu } from '../../_models/rolemenu';
import { RoleMenuService } from '../../_services/rolemenu.service';

@Component({
  selector: 'app-rolemenu',
  templateUrl: './rolemenu.component.html',
  styleUrls: ['./rolemenu.component.sass']
})
export class RolemenuComponent implements OnInit {

  rolemenu = {} as Rolemenu;
  AddRoleMenuForm = {} as FormGroup;
  RemoveRoleMenuForm = {} as FormGroup;
  constructor(private menuroleService: RoleMenuService, private notifyService: NotificationService, private router: ActivatedRoute, private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.fomrmInit();
    this.loadData();
  }
  getAll(id: string) {
    debugger;
    this.menuroleService.getById('RoleMenus/GetAllByRole', id).subscribe((role: Rolemenu) => {
      this.rolemenu = role;

    });
  }
  loadData() {
    this.router.queryParams.subscribe(params => {
      console.log(params.uid);
      this.getAll(params.uid);
    });
  }
  AddRoleMenu() {
    debugger;
    if (this.AddRoleMenuForm.value.menuId) {
      this.rolemenu.menuId = this.AddRoleMenuForm.value.menuId;
      this.menuroleService.create('RoleMenus/AssignToRole', this.rolemenu).subscribe(() => {
        this.notifyService.showSuccess("Data Saved successfully !!", "Menu")
        this.loadData();
      })
    }
  }
  RemoveRoleMenu() {
    debugger;
    if (this.RemoveRoleMenuForm.value.menuId) {
      this.rolemenu.menuId = this.RemoveRoleMenuForm.value.menuId;
      this.menuroleService.create('RoleMenus/RemoveFromRole', this.rolemenu).subscribe(() => {
        this.notifyService.showSuccess("Data Removed successfully !!", "Menu")
        this.loadData();
      })
    }
  }
  fomrmInit() {

    this.AddRoleMenuForm = this.formBuilder.group({
      menuId: [],


    });
    this.RemoveRoleMenuForm = this.formBuilder.group({
      menuId: [],


    });
  }

}
