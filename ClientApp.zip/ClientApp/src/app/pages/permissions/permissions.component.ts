import { Component, OnInit, ViewChild } from '@angular/core';
import { Subject } from 'rxjs';
import { Permission } from '../../_models/permission';
import { PermissionService } from '../../_services/permission.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-permissions',
  templateUrl: './permissions.component.html',
  styleUrls: ['./permissions.component.sass']
})
export class PermissionsComponent implements OnInit {
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();
  permission = {} as Permission;
  permissionlist: Permission[] | undefined;

  displayedColumns: string[] = ['name', 'controllerName', 'actionName', 'isActive'];
  dataSource: MatTableDataSource<Permission> = new MatTableDataSource<Permission>();

 // @ViewChild(MatPaginator) paginator: MatPaginator | undefined;
  //@ViewChild(MatSort) sort: MatSort;

  constructor(private permissionService: PermissionService) { }

  ngOnInit(): void {
    this.getAll();
    this.loadDataTable();
    
  }
  getAll() {
    debugger;
    this.permissionService.get('Permissions/Get').subscribe((prm: Permission[]) => {
      this.permissionlist = prm;
      this.dataSource = new MatTableDataSource(this.permissionlist);
      this.dtTrigger.next();
    });
  }
  loadDataTable() {
    this.dtOptions = {
      pagingType: "simple_numbers",
      pageLength: 10,
      processing: true,

    };
   
  }
  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }
  ngAfterViewInit() {
    //this.dataSource.paginator = this.paginator;
    //this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
}
