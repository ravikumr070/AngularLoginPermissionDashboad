import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import 'datatables.net'
import { Roles } from '../../_models/roles';
import { RolesService } from '../../_services/roles.service';
import { NotificationService } from '../../_services/notification.service';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.sass']
})
export class RolesComponent implements OnInit {
  //dtOptions: any = {};
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();
  role = {} as Roles;
  rolelist: Roles[] | undefined;
  
  rolesForm = {} as FormGroup;
  display = 'none'; //default Variable
  isFormSubmitted = false;
    dtElement: any;

  constructor(private roleService: RolesService, private notifyService: NotificationService, private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    
    this.getAll();
    this.loadDataTable();
    this.fomrmInit();
   
  }
  getAll() {
    debugger;
    this.roleService.get('Roles/Get').subscribe((roles: Roles[]) => {
      this.rolelist = roles;
      this.dtTrigger.next();
    });
  }
  loadDataTable() {
    this.dtOptions = {
      pagingType: "simple_numbers",
      pageLength: 10,
      processing: true,
     // destroy: true
     
    };
    //setTimeout(() => {
    //  $('#tblRoles').DataTable({
    //    pagingType: 'full_numbers',
    //    pageLength: 10,
    //    processing: true,
    //    lengthMenu: [5, 10, 25,50,100,200,500]
    //  });
    //}, 1);
  }
  
  showToasterSuccess() {
    this.notifyService.showSuccess("Data shown successfully !!", "Role")
  }

  showToasterError() {
    this.notifyService.showError("Something is wrong", "Role")
  }

  showToasterInfo() {
    this.notifyService.showInfo("This is info", "Role")
  }

  showToasterWarning() {
    this.notifyService.showWarning("This is warning", "Role")
  }
  fomrmInit() {
    const PAT_NAME = "^[a-zA-Z ]{2,20}$";
   
    this.rolesForm = this.formBuilder.group({
      id:[],
      name: ['', [Validators.required, Validators.pattern(PAT_NAME)]],
     
    });
  }
  Save() {

    // Set flag to true
    this.isFormSubmitted = true;
    if (this.rolesForm.invalid) {
      return;
    }
    // Form field values
    console.log(this.rolesForm.value.name);
    this.saveData(this.rolesForm.value);
   
  }
  closeModal() {

  }
  saveData(form: NgForm) {
    debugger;
    if (this.rolesForm.value.id !== undefined && this.rolesForm.value.id !== null) {
      this.roleService.update('Roles/Edit', this.rolesForm.value).subscribe(() => {
        this.notifyService.showSuccess("Data Updated successfully !!", "Role")
        this.closeModalDialog();
        this.cleanForm(form);

      });
    } else {
      this.roleService.create('Roles/Create', this.rolesForm.value).subscribe(() => {
        this.notifyService.showSuccess("Data Saved successfully !!", "Role")
        this.closeModalDialog();
        this.cleanForm(form);
      });
    }

  }
  Edit(item) {
    debugger;
    this.rolesForm.patchValue(item);
    this.openModalDialog();
  }
  cleanForm(form: NgForm) {
    this.getAll();
    this.rolesForm.reset();
    this.role = {} as Roles;
   
  }
  openModalDialog() {
    this.display = 'block'; //Set block css
  }

  closeModalDialog() {
    this.rolesForm.reset();
    this.display = 'none'; //set none css after close dialog
  }
  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }
}
