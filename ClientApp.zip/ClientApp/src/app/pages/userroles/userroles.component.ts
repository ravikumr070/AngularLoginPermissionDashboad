import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Userrole } from '../../_models/userroles';
import { NotificationService } from '../../_services/notification.service';
import { UserroleService } from '../../_services/userrole.service';

@Component({
  selector: 'app-userroles',
  templateUrl: './userroles.component.html',
  styleUrls: ['./userroles.component.sass']
})
export class UserrolesComponent implements OnInit {
  userrole = {} as Userrole;
  usersAddRoleForm = {} as FormGroup;
  usersRemoveRoleForm = {} as FormGroup;
  constructor(private userroleService: UserroleService, private notifyService: NotificationService, private router: ActivatedRoute, private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.fomrmInit();
    this.loadData();
  }
  getAll(id : string) {
    debugger;
    this.userroleService.getById('Users/UserRoles',id).subscribe((role: Userrole) => {
      this.userrole = role;
    
    });
  }
  loadData() {
    this.router.queryParams.subscribe(params => {
      console.log(params.uid);
      this.getAll(params.uid);
    });
  }
  AddRole() {
    debugger;
    if (this.usersAddRoleForm.value.userRole) {
      this.userrole.userRole = this.usersAddRoleForm.value.userRole;
      this.userroleService.create('Users/AddToRole', this.userrole).subscribe(() => {
        this.notifyService.showSuccess("Data Saved successfully !!", "Role")
        this.loadData();
      })
    }
  }
  RemoveRole() {
    debugger;
    if (this.usersRemoveRoleForm.value.userRole) {
      this.userrole.userRole = this.usersRemoveRoleForm.value.userRole;
      this.userroleService.create('Users/RemoveFromRole', this.userrole).subscribe(() => {
        this.notifyService.showSuccess("Data Removed successfully !!", "Role")
        this.loadData();
      })
    }
  }
  fomrmInit() {
   
    this.usersAddRoleForm = this.formBuilder.group({
      userRole: [],
     

    });
    this.usersRemoveRoleForm = this.formBuilder.group({
      userRole: [],


    });
  }
}
