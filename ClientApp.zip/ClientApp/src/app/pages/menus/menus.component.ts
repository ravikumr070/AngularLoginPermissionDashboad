import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { OrderByPipe } from '../../_helpers/order-by.pipe';
import { Menu } from '../../_models/menu';
import { MenuService } from '../../_services/menu.service';
import { NotificationService } from '../../_services/notification.service';

@Component({
  selector: 'app-menus',
  templateUrl: './menus.component.html',
  styleUrls: ['./menus.component.sass'],
  providers: [DatePipe, OrderByPipe]
})
export class MenusComponent implements OnInit {
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();
  menu = {} as Menu;
  menulist: any[]=[];
  menuForm = {} as FormGroup;
  display = 'none';
  isFormSubmitted = false;
  IsEdit = true;
  constructor(private menuService: MenuService, private formBuilder: FormBuilder, private router: Router, private notifyService: NotificationService
    , private datePipe: DatePipe
  ) { }

  ngOnInit(): void {
    this.fomrmInit();
    this.loadDataTable();
    this.getAll();
  }
  getAll() {
    this.menuService.get('Menus/Get').subscribe((menus: Menu[]) => {
      debugger;
      this.menulist = menus.sort();
      this.dtTrigger.next();
    });
  }
  Save() {
    debugger;
    // Set flag to true
    this.isFormSubmitted = true;
    if (this.menuForm.invalid) {
      return;
    }
    // Form field values
    console.log(this.menuForm.value.name);
    this.saveData(this.menuForm.value);

  }
  saveData(form: NgForm) {
    debugger;
    
    this.menuForm.value.isActive = true;
    this.menu = this.menuForm.value;
    this.menu.createdBy = 'Admin';
    this.menu.createdDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd')?.toString();
    this.menu.ip = '';
   
    if (this.menuForm.value.id !== undefined && this.menuForm.value.id !== null) {
      this.menuService.update('Menus/Edit', this.menu).subscribe(() => {
        this.notifyService.showSuccess("Data Updated successfully !!", "Menu")
        this.closeModalDialog();
        this.cleanForm(form);

      });
    } else {
      this.menu.id = 0;
      this.menuService.create('Menus/Create', this.menu).subscribe(() => {
        this.notifyService.showSuccess("Data Saved successfully !!", "Menu")
        this.closeModalDialog();
        this.cleanForm(form);
      });
    }

  }

  

  delete(menu: Menu) {
    this.menuService.delete('Menus/Delete', menu).subscribe(() => {
      this.getAll();
    });
  }

  cleanForm(form: NgForm) {
    this.getAll();
    form.resetForm();
    this.menu = {} as Menu;
  }
  loadDataTable() {
    this.dtOptions = {
      pagingType: "simple_numbers",
      pageLength: 10,
      processing: true,

    };
    
  }
  Edit(item) {
    debugger;
    this.IsEdit = false;
    this.menuForm.patchValue(item);
    this.openModalDialog();
  }
  
  AddMenu() {
    this.IsEdit = true;
    this.menuForm.reset();
    this.openModalDialog();
  }
  openModalDialog() {
    this.display = 'block';
  }
  AddSub(id:number) {
    this.menuForm.reset();
    this.menuForm.patchValue({ parentId: id});
   
    this.IsEdit = true;
    this.openModalDialog();
  }
  closeModalDialog() {
    this.menuForm.reset();
    this.display = 'none';
  }
  fomrmInit() {
    const PAT_NAME = "^[a-zA-Z ]{2,20}$";
   
    this.menuForm = this.formBuilder.group({
      id: [],
      parentId: [],
      sequence: ['', [Validators.required]],
      menuText: ['', [Validators.required, Validators.pattern(PAT_NAME)]],
      iconClass: [],
      pageUrl: [],
      isActive: [],
    
    });
  }
  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }
}
