import { ErrorHandler, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RolesComponent } from './roles/roles.component';
import { MenusComponent } from './menus/menus.component';
import { PermissionsComponent } from './permissions/permissions.component';
import { UsersComponent } from './users/users.component';
import { AppRoutingModule } from '../app-routing.module';
import { DataTablesModule } from 'angular-datatables';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UserrolesComponent } from './userroles/userroles.component';
import { RolepermissionsComponent } from './rolepermissions/rolepermissions.component';
import { UserpermissionsComponent } from './userpermissions/userpermissions.component';
import { UsersitesComponent } from './usersites/usersites.component';
import { DatabasemasterComponent } from './databasemaster/databasemaster.component';
import { MenustreeComponent } from './menustree/menustree.component';
import { RolemenumappingComponent } from './rolemenumapping/rolemenumapping.component';
import { RolemenuComponent } from './rolemenu/rolemenu.component';
import { ManageComponent } from './databasemaster/manage/manage.component';
import { OrderByPipe } from '../_helpers/order-by.pipe';
import { PageNotfoundComponent } from './page-notfound/page-notfound.component';
import { AuthModule } from '../auth/auth.module';
import { UserEditComponent } from './user-edit/user-edit.component';
import { ErrorpageComponent } from './errorpage/errorpage.component';
import { GlobalErrorService } from '../_services/global-error.service';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { PagesRoutingModule } from './pages-routing.module';
import { UploadfileComponent } from './uploadfile/uploadfile.component';

@NgModule({
  declarations: [
    RolesComponent,
    MenusComponent,
    PermissionsComponent,
    UsersComponent,
    UserrolesComponent,
    RolepermissionsComponent,
    UserpermissionsComponent,
    UsersitesComponent,
    DatabasemasterComponent,
    MenustreeComponent,
    RolemenumappingComponent,
    RolemenuComponent,
    ManageComponent,
    OrderByPipe,
    PageNotfoundComponent,
    UserEditComponent,
    ErrorpageComponent,
    UploadfileComponent
  ],
  imports: [
    CommonModule,
    AppRoutingModule,
    DataTablesModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    PagesRoutingModule

  ],
  providers: [
    { provide: ErrorHandler, useClass: GlobalErrorService },
  ],
  exports: [UsersComponent, RolesComponent, MenusComponent, PermissionsComponent]
})
export class PagesModule { }
