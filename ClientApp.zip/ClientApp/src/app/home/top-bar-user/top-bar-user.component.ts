import { Component, OnInit } from '@angular/core';
import { TokenStorageService } from '../../_services/token-storage.service';

@Component({
  selector: 'app-top-bar-user',
  templateUrl: './top-bar-user.component.html',
  styleUrls: ['./top-bar-user.component.sass']
})
export class TopBarUserComponent implements OnInit {

  userName: string = "";
  imageSrc: string = "";
  constructor(private tokentservice: TokenStorageService) {
    this.gatUser();
  }

  ngOnInit(): void {
  }
  gatUser() {
    debugger;
    var data = this.tokentservice.getUser();
    this.userName = data.name;
    this.imageSrc = "https://localhost:44339/Resources/img/users/" + data.profileImage;
  }

}
