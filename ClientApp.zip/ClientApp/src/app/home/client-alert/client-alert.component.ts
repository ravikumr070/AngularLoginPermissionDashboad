import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-alert',
  templateUrl: './client-alert.component.html',
  styleUrls: ['./client-alert.component.sass']
})
export class ClientAlertComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
