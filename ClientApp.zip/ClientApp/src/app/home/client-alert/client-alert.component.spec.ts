import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientAlertComponent } from './client-alert.component';

describe('ClientAlertComponent', () => {
  let component: ClientAlertComponent;
  let fixture: ComponentFixture<ClientAlertComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClientAlertComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientAlertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
