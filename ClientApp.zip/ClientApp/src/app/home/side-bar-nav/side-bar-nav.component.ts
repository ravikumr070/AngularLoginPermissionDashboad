import { Component, OnInit } from '@angular/core';
import { Menu } from '../../_models/menu';
import { MenuService } from '../../_services/menu.service';

@Component({
  selector: 'app-side-bar-nav',
  templateUrl: './side-bar-nav.component.html',
  styleUrls: ['./side-bar-nav.component.sass']
})
export class SideBarNavComponent implements OnInit {

  menu = {} as Menu;
  menulist: Menu[] | undefined;
  constructor(private menuService: MenuService) { }

  ngOnInit(): void {
    this.getAll();
  }
  getAll() {
    debugger;
    this.menuService.get('Menus/GetWithAll').subscribe((menus: Menu[]) => {
      this.menulist = menus;
    });
  }


}
