import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SideBarNavComponent } from './side-bar-nav/side-bar-nav.component';
import { LogoComponent } from './logo/logo.component';
import { SideBarUserComponent } from './side-bar-user/side-bar-user.component';
import { LoadingComponent } from './loading/loading.component';
import { AlertMessageComponent } from './alert-message/alert-message.component';
import { ClientAlertComponent } from './client-alert/client-alert.component';
import { ConfirmationMessageComponent } from './confirmation-message/confirmation-message.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { HomeLayoutComponent } from './home-layout/home-layout.component';
import { PageComponentComponent } from './page-component/page-component.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AppRoutingModule } from '../app-routing.module';
import { TopBarUserComponent } from './top-bar-user/top-bar-user.component';
import { AccessdeniedComponent } from './accessdenied/accessdenied.component';



@NgModule({
  declarations: [
    SideBarNavComponent,
    LogoComponent,
    SideBarUserComponent,
    LoadingComponent,
    AlertMessageComponent,
    ClientAlertComponent,
    ConfirmationMessageComponent,
    FooterComponent,
    HeaderComponent,
    HomeLayoutComponent,
    PageComponentComponent,
    DashboardComponent,
    TopBarUserComponent,
    AccessdeniedComponent
  ],
  imports: [
    CommonModule,
    AppRoutingModule
  ],
  exports: [SideBarNavComponent, LogoComponent, SideBarUserComponent, LoadingComponent, AlertMessageComponent, ClientAlertComponent, ConfirmationMessageComponent, FooterComponent, HeaderComponent, PageComponentComponent, DashboardComponent]
})
export class HomeModule { }
