import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirmation-message',
  templateUrl: './confirmation-message.component.html',
  styleUrls: ['./confirmation-message.component.sass']
})
export class ConfirmationMessageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
