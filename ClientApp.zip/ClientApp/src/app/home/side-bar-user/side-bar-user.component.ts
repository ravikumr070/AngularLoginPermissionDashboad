import { Component, OnInit } from '@angular/core';
import { UserEdit } from '../../_models/userEdit';
import { AuthService } from '../../_services/auth.service';
import { TokenStorageService } from '../../_services/token-storage.service';

@Component({
  selector: 'app-side-bar-user',
  templateUrl: './side-bar-user.component.html',
  styleUrls: ['./side-bar-user.component.sass']
})
export class SideBarUserComponent implements OnInit {
  userName: string = "";
  imageSrc: string = "";
  user : UserEdit = {};
  constructor(private tokentservice: TokenStorageService, private authenticationService: AuthService) {
    debugger;
    this.authenticationService.user.subscribe(x => this.user = x);
    console.log(this.user);
    this.gatUser();
  }

  ngOnInit(): void {
  }
  gatUser() {
    debugger;
    var data = this.tokentservice.getUser();
    this.userName = data.name;
    this.imageSrc = "https://localhost:44339/Resources/img/users/" + data.profileImage;
  }
}
