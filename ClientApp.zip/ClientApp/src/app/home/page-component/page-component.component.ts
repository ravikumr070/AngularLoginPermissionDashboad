import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-component',
  templateUrl: './page-component.component.html',
  styleUrls: ['./page-component.component.sass']
})
export class PageComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
