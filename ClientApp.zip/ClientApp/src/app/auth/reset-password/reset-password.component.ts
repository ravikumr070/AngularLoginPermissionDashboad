import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ConfirmedValidator } from '../../_helpers/password-cofirm';
import { NotificationService } from '../../_services/notification.service';
import { ResetpasswordService } from '../../_services/resetpassword.service';
import { TokenStorageService } from '../../_services/token-storage.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.sass']
})
export class ResetPasswordComponent implements OnInit {

  resetpasswordForm = {} as FormGroup;
  userid: string = "";
  isFormSubmitted = false;
  constructor(private resetpasswordService: ResetpasswordService, private tokentservice: TokenStorageService,
    private notifyService: NotificationService,  private router: ActivatedRoute, private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.fomrmInit();
    
  }
  fomrmInit() {

    this.resetpasswordForm = this.formBuilder.group({
      code: [''],
      userId: [''],
      password: ['', [Validators.required]],
      confirmPassword: ['', [Validators.required]],

    },
      {
        validator: ConfirmedValidator('password', 'confirmPassword')
      }
    );
    this.router.queryParams.subscribe(params => {
      this.resetpasswordForm.controls["code"].patchValue(params.code);
      this.resetpasswordForm.controls["userId"].patchValue(params.id);
    });

  }
  Save() {
    this.isFormSubmitted = true;
    if (this.resetpasswordForm.invalid) {
      return;
    }
    this.resetpasswordService.post('Auth/ResetPassword', this.resetpasswordForm.value).subscribe(data => {
      
      this.notifyService.showSuccess("Password Changed successfully !!", "User")
      debugger;
    });
  }
  gatUser() {
    debugger;
    var data = this.tokentservice.getUser();
    this.userid = data.id;

  }
}
