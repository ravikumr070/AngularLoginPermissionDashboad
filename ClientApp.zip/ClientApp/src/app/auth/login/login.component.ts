import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../_services/auth.service';
import { NotificationService } from '../../_services/notification.service';
import { TokenStorageService } from '../../_services/token-storage.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.sass']
})
export class LoginComponent implements OnInit {
  form: any = {
    username: null,
    password: null
  };
  isLoggedIn = false;
  isLoginFailed = false;
  errorMessage = '';
  roles: string[] = [];
  constructor(private authService: AuthService, private tokenStorage: TokenStorageService, private _router: Router, private notifyService: NotificationService) { }

  ngOnInit(): void {
    if (this.tokenStorage.getToken()) {
      this.isLoggedIn = true;
      this.roles = this.tokenStorage.getUser().roles;
    }
  }
  onSubmit(): void {
    const { username, password } = this.form;
    //if (this.authService.UserLogin(username, password)) {

    //  this.isLoginFailed = false;
    //  this.isLoggedIn = true;
    //  this._router.navigate(['/dashboard']);
    //}
    //else {
    //  this.notifyService.showError('Login failed','Login')
    //  this.isLoginFailed = true;
    //}
    this.authService.login(username, password).subscribe(
      data => {
        debugger;
        this.tokenStorage.saveToken(data.accessToken);
        this.getCurrentUser();
        this.tokenStorage.saveRefreshToken(data.refreshToken);
        this.isLoginFailed = false;
        this.isLoggedIn = true;
        this.roles = this.tokenStorage.getUser().roles;

        //this.reloadPage();
        this._router.navigate(['/dashboard']);
      },
      err => {
        this.errorMessage = err.error.message;
        this.isLoginFailed = true;
      }
    );
  }
  getCurrentUser() {
    this.authService.getCurrentUser().subscribe(
      data => {
        debugger;
        this.tokenStorage.saveUser(data);
        this._router.navigate(['/dashboard']);
        console.log(data);
      },
      err => {
        this.errorMessage = err.error.message;
        this.isLoginFailed = true;
      }
    );
  }
  reloadPage(): void {
    window.location.reload();
  }
}
