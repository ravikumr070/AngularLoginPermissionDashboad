import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ConfirmedValidator } from '../../_helpers/password-cofirm';
import { Changepassword } from '../../_models/changepassword';
import { ChangepasswordService } from '../../_services/changepassword.service';
import { NotificationService } from '../../_services/notification.service';
import { TokenStorageService } from '../../_services/token-storage.service';


@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.sass']
})
export class ChangePasswordComponent implements OnInit {
  changepasswordForm = {} as FormGroup;
  userid: string = "";
  isFormSubmitted = false;
  changepassword = {} as Changepassword;
  constructor(private changepasswordService: ChangepasswordService, private tokentservice: TokenStorageService,
    private notifyService: NotificationService, private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.getUser();
    this.fomrmInit();
  }
  fomrmInit() {
    
    this.changepasswordForm = this.formBuilder.group({
   
      password: ['', [Validators.required]],
      newPassword: ['', [Validators.required]],
      confirmPassword: ['', [Validators.required]],

    },
      {
        validator: ConfirmedValidator('newPassword', 'confirmPassword')
      }
    );

   
  }
  Save() {
    debugger;
    this.isFormSubmitted = true;
    if (this.changepasswordForm.invalid) {
      return;
    }
  
    this.changepassword.username = this.userid;
    this.changepassword.password = this.changepasswordForm.value.password;
    this.changepassword.newPassword = this.changepasswordForm.value.newPassword;
    this.changepassword.confirmPassword = this.changepasswordForm.value.confirmPassword;
    this.changepasswordService.create('Auth/ChangePassword', this.changepassword).subscribe(() => {
      debugger;
      
      this.notifyService.showSuccess("Password Updated successfully !!", "Chnage Password")
      
    },
      err => {

        this.notifyService.showSuccess(err.error.message, "Chnage Password")
      });
    this.notifyService.showSuccess("Password Updated successfully !!", "Chnage Password")
  }
  getUser() {
    debugger;
    var data = this.tokentservice.getUser();
    this.userid = data.username;

  }
}
