import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { catchError, filter, switchMap, take } from 'rxjs/operators';
import { AuthService } from '../_services/auth.service';
import { Router } from '@angular/router';
import { TokenStorageService } from '../_services/token-storage.service';

const TOKEN_HEADER_KEY = 'Authorization';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
  
  constructor(private authenticationService: AuthService, private router: Router, private tokenService: TokenStorageService) { }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(catchError(err => {
      if ([403].includes(err.status) && this.authenticationService.userValue) {
        // auto logout if 401 or 403 response returned from api
        this.router.navigate(['/accessdenied']);
       // this.authenticationService.logout();
      }
      if ([401].includes(err.status) && this.authenticationService.userValue) {
        // auto logout if 401 response returned from api
        debugger;
      this.authenticationService.logout();
       
       this.router.navigate(['/auth/login']);
       
      }
      const error = (err && err.error && err.error.message) || err.statusText;
      //console.error(err);
      return throwError(error);
    }))
  }
 
}
