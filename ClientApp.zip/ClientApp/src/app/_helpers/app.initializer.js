"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.appInitializer = void 0;
var TOKEN_REF = window.sessionStorage.getItem('auth-refreshtoken');
function appInitializer(authenticationService, tokenService, router) {
    return function () { return new Promise(function (resolve) {
        // attempt to refresh token on app start up to auto authenticate
        debugger;
        var token = TOKEN_REF;
        if (token) {
            authenticationService.refreshTokenservice(token)
                .subscribe(function (tokenData) {
                tokenService.saveToken(tokenData.accessToken);
                tokenService.saveRefreshToken(tokenData.refrshToken);
            })
                .add(resolve);
        }
        else {
            // router.navigate(['/auth/login']);
        }
    }); };
}
exports.appInitializer = appInitializer;
//# sourceMappingURL=app.initializer.js.map