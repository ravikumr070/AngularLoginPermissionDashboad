import { Router } from "@angular/router";
import { Token } from "../_models/token";
import { AuthService } from "../_services/auth.service";
import { TokenStorageService } from "../_services/token-storage.service";

const TOKEN_REF = window.sessionStorage.getItem('auth-refreshtoken');

export function appInitializer(authenticationService: AuthService, tokenService: TokenStorageService, router: Router) {
  return () => new Promise(resolve => {
    // attempt to refresh token on app start up to auto authenticate
    debugger;
    var token = TOKEN_REF;
    if (token) {
      authenticationService.refreshTokenservice(token)
        .subscribe((tokenData: Token) => {
          tokenService.saveToken(tokenData.accessToken);
          tokenService.saveRefreshToken(tokenData.refrshToken);

        })
        .add(resolve);
    }
    else {
     // router.navigate(['/auth/login']);
    }
  });
}
