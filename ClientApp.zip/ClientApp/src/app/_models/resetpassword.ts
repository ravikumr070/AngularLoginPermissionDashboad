import { Base } from "./base";


export interface Resetpassword extends Base{
  userId: string;
  password: string;
  confirmPassword: string;
  code: string;
 
}
