export interface BaseModel {
  id: number;
  isActive: boolean,
  isDeleted: boolean,
  createdDate: any,
  createdBy: string,
  modifiedDate: any,
  modifiedBy: string,
  ip: string,
}
