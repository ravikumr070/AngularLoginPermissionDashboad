export interface Base {
  id?: any
}
