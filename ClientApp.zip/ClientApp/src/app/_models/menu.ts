
import { BaseModel } from './baseModel';

export interface Menu extends BaseModel {
 
  parentId: number;
  sequence: string;
  menuText: string;
  iconClass: string;
  pageUrl: string;
  isActive: boolean;
  parent: Menu;
  children: Menu[];
}
