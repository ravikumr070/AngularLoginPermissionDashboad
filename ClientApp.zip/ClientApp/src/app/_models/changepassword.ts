import { Base } from "./base";


export interface Changepassword extends Base{
  username: string;
  password: string;
  newPassword: string;
  confirmPassword: string;
 
}
