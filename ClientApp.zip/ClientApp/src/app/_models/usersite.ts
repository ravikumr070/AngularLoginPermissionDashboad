import { AssignedMenu } from './assignedmenus';
import { Base } from './base';

export interface UserSite extends Base {
  role: string;
  siteMasterId: any;
  userId: string;
  assignedSites: AssignedMenu[];
  remainingSites: AssignedMenu[];

}

export interface UserSiteList extends Base {
  userId: string;
  user: UserSite;
  userRole: string;
  userSites: string[];
  remainingSites: string[];

}
