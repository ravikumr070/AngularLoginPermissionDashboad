import { AssignedMenu } from './assignedmenus';
import { Base } from './base';

export interface Rolemenu extends Base {
  roleName: string;
  menuId: any;
  assignedMenus: AssignedMenu [];
  remainingMenus: AssignedMenu[];
  
}

