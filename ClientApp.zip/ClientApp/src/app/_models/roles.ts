import { Base } from './base';

export interface Roles extends Base {
  name: string;
 
}
