import { Base } from './base';

export interface Menutree extends Base {
  userName: string;
  name: string;
  email: string;
  emailConfirmed: any;
  phoneNumber: string;
  phoneNumberConfirmed: any;
  profileImage: string;
  approved: boolean;
  companyName: string;
  companyId: any;
  profileId: any;

}
