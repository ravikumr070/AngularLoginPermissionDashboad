"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=rolepermission.js.map