

export interface Forgotpassword  {
  email: string;
 
}
