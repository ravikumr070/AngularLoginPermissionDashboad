
import { BaseModel } from './baseModel';

export interface Databasemaster extends BaseModel {
  siteId: number;
  userId: string;
  dbName: string;
  prodDbConnectionString: string;
  uATDbConnectionString: string;
  stagingDbConnectionString: string;
  dbUserId: string;
  dbPassword: string;
  dbHost: string;
 

}
