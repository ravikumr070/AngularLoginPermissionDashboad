
import { BaseModel } from './baseModel';

export interface Permission extends BaseModel {
  name: string;
  controllerName: string;
  actionName: string;
  userPermissions: any[];
  

}
