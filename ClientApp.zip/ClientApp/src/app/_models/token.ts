import { Base } from './base';

export interface Token{
  accessToken: string;
  refrshToken: string;
 

}
