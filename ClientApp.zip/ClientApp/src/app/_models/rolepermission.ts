
import { BaseModel } from './baseModel';
import { Permission } from './permission';


export interface Rolepermission extends BaseModel {
  hasPermission: boolean;
  userId: string;
  permissionId: number;
  roleId: string;
  permission: Permission;

}
export interface RolepermissionDTO extends BaseModel {
  hasPermission: boolean;
  userId: string;
  permissionId: number;
  roleId: string;

}
