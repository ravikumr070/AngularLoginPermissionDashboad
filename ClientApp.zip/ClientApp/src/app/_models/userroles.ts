import { Base } from './base';
import { Users } from './users';

export interface Userrole extends Base {
  userId: string;
  user: Users;
  userRole: string;
  userRoles: string [];
  remainingRoles: string [];
 
}
