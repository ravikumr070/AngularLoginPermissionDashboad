import { Base } from './base';

export interface AssignedMenu extends Base{
  text: string;
 
 

}
